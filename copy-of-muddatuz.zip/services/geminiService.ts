
import { GoogleGenAI } from "@google/genai";
import { Category, ScanResult, ChatMessage, User } from "../types";

// Initialize Gemini Client
// The API key is securely loaded from the environment variables
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Helper to extract clean JSON from AI response
const extractJson = (text: string) => {
  const jsonMatch = text.match(/\{[\s\S]*\}/);
  return jsonMatch ? jsonMatch[0] : "{}";
};

export const analyzeProductImage = async (base64Image: string): Promise<ScanResult> => {
  try {
    // 1. Prepare Image Data
    // Remove the "data:image/jpeg;base64," prefix if present
    const base64Data = base64Image.split(',')[1] || base64Image;

    // 2. Define the Prompt
    const prompt = `
      You are an intelligent assistant for the "MuddatUz" app. 
      Your task is to analyze the image of a product (food, medicine, cosmetic, etc.) and extract details.

      Extract the following fields and return them in strict JSON format:
      
      1. "name": The product name (e.g., "Nestle Sut", "Paracetamol", "Nivea Cream"). Keep it concise.
      2. "expiryDate": The expiration date in "YYYY-MM-DD" format. 
         - Look for keywords like "EXP", "E", "Sana", "Yaroqlilik", "Годен до".
         - If only the production date is found, estimate expiry:
           * Medicine: +3 years
           * Dairy/Food: +6 months
           * Cosmetics: +2 years
         - If no date found, return null.
      3. "category": Choose exactly one from: 
         ['Oziq-ovqat', 'Dori-darmon', 'Kosmetika', 'Obuna (Premium)', 'Hujjat', 'Texnika', 'Ro\\'zg\\'or', 'Boshqa']
      4. "price": Look for a price tag (e.g., "15 000 so'm"). Return ONLY the number (e.g., 15000). If not found, return 0.

      Output JSON only. Do not add Markdown code blocks.
      Example: {"name": "Cola 1.5L", "expiryDate": "2025-12-31", "category": "Oziq-ovqat", "price": 12000}
    `;

    // 3. Call Gemini Vision Model (Gemini 2.5 Flash is best for speed/accuracy)
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          { inlineData: { mimeType: 'image/jpeg', data: base64Data } },
          { text: prompt }
        ]
      },
      config: {
        temperature: 0.1, // Low temperature for factual extraction
      }
    });

    const text = response.text || "{}";
    const jsonStr = extractJson(text);
    const result = JSON.parse(jsonStr);

    // 4. Validate Category
    let category = Category.OTHER;
    if (Object.values(Category).includes(result.category)) {
      category = result.category as Category;
    }

    return {
      name: result.name || "Noma'lum Mahsulot",
      expiryDate: result.expiryDate || null,
      category: category,
      price: typeof result.price === 'number' ? result.price : 0
    };

  } catch (error) {
    console.error("Gemini Vision Error:", error);
    // Fallback in case of error
    return { name: "Tahlil xatosi", expiryDate: null, category: Category.OTHER, price: 0 };
  }
};

export const chatWithAli = async (
  history: ChatMessage[], 
  newMessage: string, 
  user: User,
  productsContext: string
): Promise<string> => {
  try {
    const systemInstruction = `
      Sening isming Ali. Sen "MuddatUz" ilovasining aqlli yordamchisisan.
      Foydalanuvchi: ${user.name} ${user.surname} (Yoshi: ${user.age}).
      
      Foydalanuvchining omboridagi mahsulotlar:
      ${productsContext}

      Vazifalaring:
      1. Mahsulotlarning muddati tugayotgani haqida ogohlantirish.
      2. Agar oziq-ovqat bo'lsa, undan nima ovqat pishirish mumkinligini aytish.
      3. Iqtisod (qancha pul tejagani yoki yo'qotgani) haqida maslahat berish.
      4. Javoblaring qisqa, lo'nda va samimiy O'zbek tilida bo'lsin.
    `;

    // Convert history to Gemini format
    // Gemini expects 'user' and 'model' roles. We map 'assistant' -> 'model'.
    const chatHistory = history.map(msg => ({
      role: msg.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: msg.content }]
    }));

    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: systemInstruction,
      },
      history: chatHistory
    });

    const result = await chat.sendMessage({ message: newMessage });
    return result.text;

  } catch (error) {
    console.error("Gemini Chat Error:", error);
    return "Uzr, hozir javob bera olmayman. Internetni tekshiring.";
  }
};
