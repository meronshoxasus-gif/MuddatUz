
import { Category, ScanResult, ChatMessage, User } from "../types";

const GROQ_API_KEY = "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";

// Helper to extract JSON from text using Regex (more robust)
const extractJson = (str: string) => {
  const jsonMatch = str.match(/\{[\s\S]*\}/);
  return jsonMatch ? jsonMatch[0] : str;
};

async function groqRequest(messages: any[], model: string, jsonMode = false) {
  const body: any = {
    messages: messages,
    model: model,
    temperature: 0.1, // Very low temperature for consistent JSON
    max_tokens: 1024,
  };

  // Only add response_format for text models that support it, NOT vision models
  if (jsonMode && !model.includes('vision')) {
      body.response_format = { type: "json_object" };
  }

  try {
    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${GROQ_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Groq API Error Details:", errorText);
      throw new Error(`API Error: ${response.status}`);
    }

    const data = await response.json();
    return data.choices[0]?.message?.content;
  } catch (error) {
    console.error("Groq Request Failed:", error);
    throw error;
  }
}

export const analyzeProductImage = async (base64Image: string): Promise<ScanResult> => {
  try {
    // English prompt often works better for structural compliance, even if we want Uzbek output
    const prompt = `
      You are an expert product analyzer for the Uzbek market.
      Analyze the image provided and extract product details.
      
      Look for:
      1. PRODUCT NAME (Name): Brand and specific product name (e.g., "Nestle Sut", "Amoxicillin").
      2. EXPIRY DATE (ExpiryDate): Look for "EXP", "Date", "Sana", "Yaroqlilik". Format: YYYY-MM-DD. If only production date is found, estimate expiry (e.g. +2 years for meds, +6 months for dairy).
      3. CATEGORY (Category): Choose one from list: 'Oziq-ovqat', 'Dori-darmon', 'Kosmetika', 'Obuna (Premium)', 'Hujjat', 'Texnika', 'Ro\\'zg\\'or', 'Boshqa'.
      4. PRICE (Price): Look for price tags (e.g. 15000 so'm). Return only the number. If none found, return 0.

      RETURN ONLY RAW JSON. DO NOT USE MARKDOWN. NO \`\`\`json tags.
      
      JSON Structure:
      {
        "name": "string",
        "expiryDate": "YYYY-MM-DD" or null,
        "category": "string",
        "price": number
      }
    `;

    // Using llama-3.2-11b-vision-preview as it is the standard vision model
    const content = await groqRequest([
      {
        role: "user",
        content: [
          { type: "text", text: prompt },
          { type: "image_url", image_url: { url: base64Image } }
        ]
      }
    ], "llama-3.2-11b-vision-preview", false);

    const jsonStr = extractJson(content);
    
    let result;
    try {
        result = JSON.parse(jsonStr);
    } catch (e) {
        console.error("JSON Parse Error on Vision:", e, "Content:", content);
        // Fallback if JSON fails
        return { name: "Aniqlab bo'lmadi", expiryDate: null, category: Category.OTHER, price: 0 };
    }
    
    let category = Category.OTHER;
    if (Object.values(Category).includes(result.category)) {
      category = result.category as Category;
    }

    return {
      name: result.name || "Noma'lum",
      expiryDate: result.expiryDate || null,
      category: category,
      price: typeof result.price === 'number' ? result.price : 0
    };
  } catch (error) {
    console.error("AI Analysis Error:", error);
    return { name: "Xatolik", expiryDate: null, category: Category.OTHER, price: 0 };
  }
};

export const chatWithAli = async (
  history: ChatMessage[], 
  newMessage: string, 
  user: User,
  productsContext: string
): Promise<string> => {
  try {
    const systemPrompt = `
      Isming Ali. Sen MuddatUz ilovasining moliyaviy va tovar bo'yicha maslahatchisisan.
      Foydalanuvchi: ${user.name} ${user.surname}.
      
      Foydalanuvchining mahsulotlari va narxlari:
      ${productsContext}

      Vazifang:
      1. Mahsulotlar muddati haqida ogohlantirish.
      2. Agar mahsulot muddati oz qolgan bo'lsa, undan nima pishirish yoki qanday foydalanish haqida maslahat berish.
      3. Iqtisod (Economy) haqida gapirish. Qancha pul tejagani yoki yo'qotgani haqida tahlil qil.
      
      Javobing samimiy, O'zbek tilida va qisqa bo'lsin.
    `;

    // Limit history to last 10 messages
    const recentHistory = history.slice(-10);

    const messages = [
      { role: "system", content: systemPrompt },
      ...recentHistory
    ];

    // Using llama-3.3-70b-versatile for text chat
    return await groqRequest(messages, "llama-3.3-70b-versatile", false);
  } catch (error) {
    return "Uzr, internet pastlik qilyapti shekilli yoki tizimda xatolik. Qayta yozib ko'ring.";
  }
};
