
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  PlusCircle, 
  List, 
  CheckCircle, 
  Clock, 
  Trash2,
  ChevronLeft,
  LogOut,
  Home,
  MessageCircle,
  ScanLine,
  Search,
  Edit2,
  Image as ImageIcon,
  Camera,
  UploadCloud,
  RefreshCw,
  AlertCircle
} from 'lucide-react';
import { Product, ViewState, Category, User, ChatMessage } from './types';
import { analyzeProductImage, chatWithAli } from './services/geminiService';
import { Auth } from './components/Auth';
import { AliChat } from './components/AliChat';
import { EconomyChart } from './components/EconomyChart';

// --- Helper Functions ---

const getDaysRemaining = (expiryDate: string): number => {
  if (!expiryDate) return 0;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expiry = new Date(expiryDate);
  expiry.setHours(0, 0, 0, 0);
  
  const diffTime = expiry.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
};

const getCategoryBadge = (cat: Category) => {
  switch (cat) {
    case Category.FOOD: return { icon: '🍎', color: 'bg-red-100 text-red-700' };
    case Category.MEDICINE: return { icon: '💊', color: 'bg-blue-100 text-blue-700' };
    case Category.COSMETIC: return { icon: '💄', color: 'bg-pink-100 text-pink-700' };
    case Category.SUBSCRIPTION: return { icon: '💳', color: 'bg-purple-100 text-purple-700' };
    case Category.DOCUMENT: return { icon: '📄', color: 'bg-yellow-100 text-yellow-700' };
    case Category.TECH: return { icon: '💻', color: 'bg-gray-100 text-gray-700' };
    default: return { icon: '📦', color: 'bg-gray-100 text-gray-700' };
  }
};

const formatDate = (dateString: string) => {
  if (!dateString) return 'Sana yo\'q';
  return new Date(dateString).toLocaleDateString('uz-UZ', { year: 'numeric', month: 'long', day: 'numeric' });
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [view, setView] = useState<ViewState>('dashboard');
  const [products, setProducts] = useState<Product[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Form State
  const [formData, setFormData] = useState<Partial<Product>>({
    name: '',
    expiryDate: '',
    category: Category.FOOD,
    price: 0
  });
  const [loadingAI, setLoadingAI] = useState(false);
  const [formError, setFormError] = useState('');
  
  // Refs for file inputs
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  // Chat State
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);

  // --- Persistence ---
  useEffect(() => {
    const savedUser = localStorage.getItem('muddatuz_active_user');
    if (savedUser) setUser(JSON.parse(savedUser));

    const savedProducts = localStorage.getItem('muddatuz_products');
    if (savedProducts) setProducts(JSON.parse(savedProducts));
    
    const savedChat = localStorage.getItem('muddatuz_chat');
    if (savedChat) setChatHistory(JSON.parse(savedChat));
  }, []);

  useEffect(() => {
    if (user) localStorage.setItem('muddatuz_active_user', JSON.stringify(user));
    else localStorage.removeItem('muddatuz_active_user');
  }, [user]);

  useEffect(() => {
    localStorage.setItem('muddatuz_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('muddatuz_chat', JSON.stringify(chatHistory));
  }, [chatHistory]);

  // --- Handlers ---

  const handleLogout = () => {
    if(confirm("Chiqishni xohlaysizmi?")) {
      setUser(null);
      setChatHistory([]);
      localStorage.removeItem('muddatuz_chat');
    }
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    // Validation
    if (!formData.name || !formData.name.trim()) {
      setFormError("Mahsulot nomini kiritish shart!");
      return;
    }
    if (!formData.expiryDate) {
      setFormError("Yaroqlilik muddatini kiritish shart!");
      return;
    }

    if (formData.id) {
        // Edit existing product
        setProducts(prev => prev.map(p => p.id === formData.id ? { ...p, ...formData } as Product : p));
    } else {
        // Add new product
        const newProduct: Product = {
            id: Date.now().toString(),
            name: formData.name,
            expiryDate: formData.expiryDate,
            category: formData.category || Category.FOOD,
            addedDate: new Date().toISOString(),
            image: formData.image,
            price: formData.price || 0
        };
        setProducts(prev => [newProduct, ...prev]);
    }

    // Reset and redirect
    setFormData({ name: '', expiryDate: '', category: Category.FOOD, image: undefined, id: undefined, price: 0 });
    setView('list');
  };

  const handleDeleteProduct = (id: string) => {
    if(confirm("Haqiqatan ham bu mahsulotni o'chirmoqchimisiz?")) {
        setProducts(p => p.filter(x => x.id !== id));
    }
  };

  const handleEditProduct = (product: Product) => {
    setFormData(product);
    setFormError('');
    setView('add');
  };

  const resetForm = () => {
    setFormData({ name: '', expiryDate: '', category: Category.FOOD, image: undefined, id: undefined, price: 0 });
    setFormError('');
    setView('add');
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setLoadingAI(true);
      
      // Use FileReader to read file
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
           // Resize image to max 1024px to prevent API errors
           const canvas = document.createElement('canvas');
           const MAX_SIZE = 1024;
           let width = img.width;
           let height = img.height;
           
           if (width > height) {
             if (width > MAX_SIZE) {
               height *= MAX_SIZE / width;
               width = MAX_SIZE;
             }
           } else {
             if (height > MAX_SIZE) {
               width *= MAX_SIZE / height;
               height = MAX_SIZE;
             }
           }
           
           canvas.width = width;
           canvas.height = height;
           const ctx = canvas.getContext('2d');
           if(ctx) {
             ctx.drawImage(img, 0, 0, width, height);
             const base64 = canvas.toDataURL('image/jpeg', 0.8);
             handleScan(base64);
           }
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
      
      // Reset input value so same file can be selected again if needed
      e.target.value = '';
    }
  };

  const handleScan = async (base64Image: string) => {
    setLoadingAI(true);
    setFormData(prev => ({ ...prev, image: base64Image }));
    
    try {
      const result = await analyzeProductImage(base64Image);
      setFormData(prev => ({
        ...prev,
        name: result.name,
        expiryDate: result.expiryDate || '',
        category: result.category,
        price: result.price
      }));
    } catch (error) {
      setFormError("Tahlil qilishda xatolik. Iltimos qo'lda kiriting.");
    } finally {
      setLoadingAI(false);
    }
  };

  // Helper to trigger scan again on current image
  const handleReAnalyze = () => {
    if (formData.image) {
      handleScan(formData.image);
    }
  };

  const handleChatSend = async () => {
    if (!chatInput.trim() || !user) return;

    const userMsg: ChatMessage = { role: 'user', content: chatInput };
    const newHistory = [...chatHistory, userMsg];
    
    setChatHistory(newHistory);
    setChatInput('');
    setChatLoading(true);

    const productSummary = products.map(p => 
      `- ${p.name} (${p.category}): Muddat ${p.expiryDate}, Narx: ${p.price || 0} so'm`
    ).join('\n');

    const reply = await chatWithAli(newHistory, userMsg.content, user, productSummary);
    
    setChatHistory([...newHistory, { role: 'assistant', content: reply }]);
    setChatLoading(false);
  };

  // --- Statistics ---
  const stats = useMemo(() => {
    let expired = 0, warning = 0, good = 0;
    products.forEach(p => {
      const days = getDaysRemaining(p.expiryDate);
      if (days < 0) expired++;
      else if (days <= 5) warning++;
      else good++;
    });
    return { expired, warning, good };
  }, [products]);

  const filteredProducts = useMemo(() => {
    return products
      .filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()))
      .sort((a, b) => new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime());
  }, [products, searchTerm]);

  // --- Render ---

  if (!user) return <Auth onLogin={setUser} />;

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 pb-20 font-sans">
      
      {/* Dynamic Header */}
      <header className={`px-6 pt-10 pb-6 shadow-sm transition-all ${view === 'dashboard' ? 'bg-indigo-600 text-white rounded-b-3xl' : 'bg-white text-gray-800'}`}>
        <div className="flex justify-between items-center max-w-lg mx-auto">
          {view === 'dashboard' ? (
             <div>
                <p className="opacity-80 text-sm font-medium">Salom, {user.name}</p>
                <h1 className="text-2xl font-bold">MuddatUz</h1>
             </div>
          ) : (
            <div className="flex items-center gap-2">
               {view !== 'list' && <button onClick={() => setView('dashboard')}><ChevronLeft size={24}/></button>}
               <h1 className="text-xl font-bold">
                 {view === 'add' ? (formData.id ? 'Tahrirlash' : 'Yangi Mahsulot') : view === 'list' ? 'Mening Mahsulotlarim' : view === 'chat' ? 'Ali Yordamchi' : 'Profil'}
               </h1>
            </div>
          )}
          {view === 'dashboard' && (
             <button onClick={handleLogout} className="bg-white/20 p-2 rounded-xl backdrop-blur-md hover:bg-white/30 transition">
               <LogOut size={20} className="text-white" />
             </button>
          )}
        </div>

        {/* Dashboard Cards */}
        {view === 'dashboard' && (
          <div className="max-w-lg mx-auto mt-8 grid grid-cols-3 gap-3 text-center">
             <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/20">
                <div className="text-2xl font-bold mb-1">{stats.good}</div>
                <div className="text-xs opacity-80">Yaxshi</div>
             </div>
             <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/20 text-yellow-300">
                <div className="text-2xl font-bold mb-1">{stats.warning}</div>
                <div className="text-xs opacity-80 text-white">Oz qoldi</div>
             </div>
             <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/20 text-red-300">
                <div className="text-2xl font-bold mb-1">{stats.expired}</div>
                <div className="text-xs opacity-80 text-white">Tugadi</div>
             </div>
          </div>
        )}
      </header>

      <main className="max-w-lg mx-auto px-4 mt-6 space-y-6">
        
        {/* VIEW: DASHBOARD */}
        {view === 'dashboard' && (
          <div className="space-y-6">
             {/* Action Banner */}
             <div onClick={resetForm} className="bg-gradient-to-r from-purple-500 to-indigo-500 rounded-2xl p-4 text-white shadow-lg shadow-indigo-200 flex items-center justify-between cursor-pointer active:scale-95 transition">
                <div>
                  <h3 className="font-bold text-lg">Yangi qo'shish</h3>
                  <p className="text-sm opacity-90">Rasmga oling yoki yozing</p>
                </div>
                <div className="bg-white/20 p-2 rounded-full">
                  <ScanLine size={24} />
                </div>
             </div>

             {/* Real-time Economy Chart */}
             <EconomyChart products={products} />

             {/* Recent Urgent Items */}
             <div>
               <h3 className="font-bold text-gray-700 text-lg px-1 mb-3">Diqqat talablar</h3>
               {stats.warning + stats.expired === 0 ? (
                 <div className="text-center py-6 text-gray-400 bg-white rounded-2xl border border-dashed border-gray-200">
                    <CheckCircle className="mx-auto mb-2 text-green-500" />
                    <p>Hammasi joyida!</p>
                 </div>
               ) : (
                 <div className="space-y-3">
                   {products.filter(p => getDaysRemaining(p.expiryDate) <= 5).slice(0, 3).map(product => {
                      const days = getDaysRemaining(product.expiryDate);
                      return (
                        <div key={product.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex items-center gap-3">
                           <div className={`w-10 h-10 rounded-full flex items-center justify-center text-lg ${getCategoryBadge(product.category).color}`}>
                             {getCategoryBadge(product.category).icon}
                           </div>
                           <div className="flex-1">
                             <h4 className="font-bold text-gray-800">{product.name}</h4>
                             <p className="text-xs text-gray-500">{product.category}</p>
                           </div>
                           <div className={`text-xs font-bold px-2 py-1 rounded-md ${days < 0 ? 'bg-red-100 text-red-600' : 'bg-yellow-100 text-yellow-600'}`}>
                             {days < 0 ? 'Tugagan' : `${days} kun`}
                           </div>
                        </div>
                      )
                   })}
                 </div>
               )}
             </div>
          </div>
        )}

        {/* VIEW: LIST */}
        {view === 'list' && (
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 text-gray-400" size={18} />
              <input 
                type="text" 
                placeholder="Qidirish..." 
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 outline-none"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
              />
            </div>

            <div className="space-y-3">
              {filteredProducts.length === 0 ? (
                <div className="text-center py-10 text-gray-400">Hech narsa topilmadi</div>
              ) : (
                filteredProducts.map(product => {
                  const days = getDaysRemaining(product.expiryDate);
                  return (
                    <div key={product.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex items-center gap-3">
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center text-xl ${getCategoryBadge(product.category).color}`}>
                          {getCategoryBadge(product.category).icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-bold text-gray-800 truncate">{product.name}</h4>
                          <div className="flex gap-3 mt-1">
                              <p className="text-xs text-gray-500 flex items-center gap-1">
                                <Clock size={10} /> {formatDate(product.expiryDate)}
                              </p>
                              {product.price ? (
                                <p className="text-xs text-emerald-600 font-medium">
                                   {product.price.toLocaleString()} so'm
                                </p>
                              ) : null}
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-1">
                           <span className={`text-xs font-bold ${days < 0 ? 'text-red-600' : days <= 5 ? 'text-yellow-600' : 'text-green-600'}`}>
                             {days < 0 ? 'Tugagan' : `${days} kun`}
                           </span>
                           <div className="flex gap-2 mt-1">
                                <button onClick={() => handleEditProduct(product)} className="text-gray-300 hover:text-indigo-500 bg-gray-50 p-1.5 rounded-lg">
                                    <Edit2 size={16} />
                                </button>
                                <button onClick={() => handleDeleteProduct(product.id)} className="text-gray-300 hover:text-red-500 bg-gray-50 p-1.5 rounded-lg">
                                    <Trash2 size={16} />
                                </button>
                           </div>
                        </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* VIEW: ADD/EDIT */}
        {view === 'add' && (
          <div className="bg-white rounded-2xl shadow-sm p-6 space-y-6">
            
            {/* Hidden Inputs */}
            <input 
                type="file" 
                ref={cameraInputRef}
                accept="image/*"
                capture="environment" 
                className="hidden"
                onChange={handleFileSelect}
            />
            <input 
                type="file" 
                ref={galleryInputRef}
                accept="image/*"
                className="hidden"
                onChange={handleFileSelect}
            />

            <div className="space-y-4">
              {/* Image Preview Area */}
              {formData.image && (
                 <div className="relative w-full h-56 bg-gray-100 rounded-2xl overflow-hidden shadow-inner">
                    <img src={formData.image} alt="Preview" className="w-full h-full object-contain" />
                    {loadingAI && (
                       <div className="absolute inset-0 bg-black/50 flex flex-col items-center justify-center text-white backdrop-blur-sm z-10">
                          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mb-2"></div>
                          <span className="text-sm font-bold">AI Tahlil qilmoqda...</span>
                       </div>
                    )}
                 </div>
              )}

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-3">
                 <button 
                   type="button"
                   onClick={() => cameraInputRef.current?.click()}
                   className="flex items-center justify-center gap-2 p-4 rounded-xl bg-indigo-50 text-indigo-700 font-bold hover:bg-indigo-100 transition active:scale-95"
                 >
                    <Camera size={20} />
                    Rasmga olish
                 </button>
                 <button 
                   type="button"
                   onClick={() => galleryInputRef.current?.click()}
                   className="flex items-center justify-center gap-2 p-4 rounded-xl bg-purple-50 text-purple-700 font-bold hover:bg-purple-100 transition active:scale-95"
                 >
                    <ImageIcon size={20} />
                    Galereya
                 </button>
              </div>

              {/* Re-analyze Button */}
              {formData.image && !loadingAI && (
                 <button 
                    type="button" 
                    onClick={handleReAnalyze}
                    className="w-full py-2 text-gray-500 text-xs font-medium flex items-center justify-center gap-1 hover:text-indigo-600"
                 >
                    <RefreshCw size={12} /> Qayta tahlil qilish
                 </button>
              )}
            </div>

            {formError && (
              <div className="bg-red-50 text-red-600 p-3 rounded-xl text-sm font-medium flex items-center gap-2 border border-red-100 animate-pulse">
                <AlertCircle size={18} />
                {formError}
              </div>
            )}

            <form onSubmit={handleSaveProduct} className="space-y-4 border-t border-gray-100 pt-4">
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Mahsulot nomi *</label>
                <input 
                  type="text" 
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  className={`w-full p-3 rounded-xl bg-gray-50 border focus:ring-2 focus:ring-indigo-500 outline-none font-medium ${formError && !formData.name ? 'border-red-300 ring-2 ring-red-100' : 'border-gray-200'}`}
                  placeholder="Masalan: Sut, Dori..."
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Muddati *</label>
                    <input 
                      type="date" 
                      value={formData.expiryDate}
                      onChange={e => setFormData({...formData, expiryDate: e.target.value})}
                      className={`w-full p-3 rounded-xl bg-gray-50 border focus:ring-2 focus:ring-indigo-500 outline-none ${formError && !formData.expiryDate ? 'border-red-300 ring-2 ring-red-100' : 'border-gray-200'}`}
                    />
                 </div>
                 <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Kategoriya</label>
                    <select 
                      value={formData.category}
                      onChange={e => setFormData({...formData, category: e.target.value as Category})}
                      className="w-full p-3 rounded-xl bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-indigo-500 outline-none"
                    >
                      {Object.values(Category).map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                 </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Narxi (So'm)</label>
                <input 
                  type="number" 
                  value={formData.price || ''}
                  onChange={e => setFormData({...formData, price: Number(e.target.value)})}
                  className="w-full p-3 rounded-xl bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-indigo-500 outline-none font-medium"
                  placeholder="0"
                />
              </div>

              <div className="flex gap-3 pt-4">
                  {formData.id && (
                      <button 
                        type="button" 
                        onClick={() => setView('list')} 
                        className="w-1/3 bg-gray-100 text-gray-600 py-4 rounded-xl font-bold hover:bg-gray-200 transition"
                      >
                        Bekor
                      </button>
                  )}
                  <button type="submit" className="flex-1 bg-indigo-600 text-white py-4 rounded-xl font-bold hover:bg-indigo-700 active:scale-95 transition shadow-lg shadow-indigo-200">
                     {formData.id ? 'Yangilash' : 'Saqlash'}
                  </button>
              </div>
            </form>
          </div>
        )}

        {/* VIEW: CHAT */}
        {view === 'chat' && (
           <div className="h-[calc(100vh-140px)] rounded-2xl overflow-hidden shadow-sm border border-gray-200">
              <AliChat 
                messages={chatHistory} 
                input={chatInput} 
                setInput={setChatInput} 
                onSend={handleChatSend} 
                isLoading={chatLoading} 
              />
           </div>
        )}

      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 w-full bg-white border-t border-gray-100 pb-safe pt-2 px-6 flex justify-between items-center z-40 text-xs font-medium text-gray-400">
         <button onClick={() => setView('dashboard')} className={`flex flex-col items-center p-2 rounded-xl transition ${view === 'dashboard' ? 'text-indigo-600 bg-indigo-50' : 'hover:bg-gray-50'}`}>
            <Home size={24} className="mb-1" />
            <span>Asosiy</span>
         </button>
         <button onClick={resetForm} className={`flex flex-col items-center p-2 rounded-xl transition ${view === 'add' ? 'text-indigo-600 bg-indigo-50' : 'hover:bg-gray-50'}`}>
            <PlusCircle size={24} className="mb-1" />
            <span>Qo'shish</span>
         </button>
         <button onClick={() => setView('list')} className={`flex flex-col items-center p-2 rounded-xl transition ${view === 'list' ? 'text-indigo-600 bg-indigo-50' : 'hover:bg-gray-50'}`}>
            <List size={24} className="mb-1" />
            <span>Ro'yxat</span>
         </button>
         <button onClick={() => setView('chat')} className={`flex flex-col items-center p-2 rounded-xl transition ${view === 'chat' ? 'text-indigo-600 bg-indigo-50' : 'hover:bg-gray-50'}`}>
            <MessageCircle size={24} className="mb-1" />
            <span>Ali AI</span>
         </button>
      </nav>
    </div>
  );
}
