
import React, { useRef, useState, useCallback } from 'react';
import { Camera, X, Check } from 'lucide-react';

interface CameraCaptureProps {
  onCapture: (base64Image: string) => void;
  onCancel: () => void;
}

export const CameraCapture: React.FC<CameraCaptureProps> = ({ onCapture, onCancel }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isCameraReady, setIsCameraReady] = useState(false);

  const startCamera = useCallback(async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } 
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        videoRef.current.onloadedmetadata = () => {
            setIsCameraReady(true);
            videoRef.current?.play();
        }
      }
    } catch (err) {
      console.error("Error accessing camera:", err);
      alert("Kameraga ruxsat berilmadi yoki kamera mavjud emas.");
      onCancel();
    }
  }, [onCancel]);

  const stopCamera = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  }, [stream]);

  const takePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');

      if (context) {
        // Calculate scale to keep image reasonable size (max 1024px) for API
        const MAX_SIZE = 1024;
        let width = video.videoWidth;
        let height = video.videoHeight;
        
        if (width > height) {
            if (width > MAX_SIZE) {
                height *= MAX_SIZE / width;
                width = MAX_SIZE;
            }
        } else {
            if (height > MAX_SIZE) {
                width *= MAX_SIZE / height;
                height = MAX_SIZE;
            }
        }

        canvas.width = width;
        canvas.height = height;
        context.drawImage(video, 0, 0, width, height);
        
        const imageData = canvas.toDataURL('image/jpeg', 0.8);
        stopCamera();
        onCapture(imageData);
      }
    }
  };

  React.useEffect(() => {
    startCamera();
    return () => stopCamera();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col">
      <div className="relative flex-1 flex items-center justify-center overflow-hidden">
         {!isCameraReady && <div className="text-white">Kamera yuklanmoqda...</div>}
        <video 
            ref={videoRef} 
            className="absolute inset-0 w-full h-full object-cover" 
            playsInline 
            muted
        />
        <canvas ref={canvasRef} className="hidden" />
        
        {/* Overlay Guide */}
        <div className="absolute border-2 border-white/50 rounded-lg w-64 h-64 pointer-events-none"></div>
        <div className="absolute top-8 left-0 w-full text-center text-white/80 bg-black/30 py-2">
            Mahsulot yorlig'ini ramkaga joylang
        </div>
      </div>

      <div className="h-32 bg-gray-900 flex items-center justify-around px-6">
        <button 
          onClick={() => { stopCamera(); onCancel(); }}
          className="p-4 rounded-full bg-gray-800 text-white hover:bg-gray-700 transition"
        >
          <X size={24} />
        </button>

        <button 
          onClick={takePhoto}
          disabled={!isCameraReady}
          className="p-5 rounded-full border-4 border-white bg-red-600 hover:bg-red-500 transition shadow-lg transform active:scale-95 disabled:opacity-50"
        >
          <Camera size={32} className="text-white" />
        </button>
        
        <div className="w-12"></div> {/* Spacer for balance */}
      </div>
    </div>
  );
};
