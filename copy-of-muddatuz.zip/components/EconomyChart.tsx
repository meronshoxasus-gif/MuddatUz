
import React from 'react';
import { Product } from '../types';

interface EconomyChartProps {
  products: Product[];
}

export const EconomyChart: React.FC<EconomyChartProps> = ({ products }) => {
  // Calculations
  const today = new Date();
  today.setHours(0,0,0,0);

  let activeValue = 0;
  let wastedValue = 0;

  products.forEach(p => {
    const price = p.price || 0;
    const expiry = new Date(p.expiryDate);
    if (expiry < today) {
        wastedValue += price;
    } else {
        activeValue += price;
    }
  });

  const totalValue = activeValue + wastedValue;
  
  // Calculate percentages for the donut slice
  // If total is 0, avoid division by zero
  const activePercent = totalValue > 0 ? (activeValue / totalValue) * 100 : 100;
  const wastedPercent = totalValue > 0 ? (wastedValue / totalValue) * 100 : 0;

  // SVG Circle Logic
  const radius = 70;
  const circumference = 2 * Math.PI * radius;
  const activeOffset = circumference - (activePercent / 100) * circumference;

  return (
    <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100 flex flex-row items-center justify-between">
      <div className="flex-1">
        <h3 className="font-bold text-gray-700 text-lg mb-1">Iqtisodiy Tahlil</h3>
        <p className="text-xs text-gray-400 mb-4">Mahsulotlaringiz qiymati</p>
        
        <div className="space-y-2">
            <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
                <div>
                    <p className="text-xs text-gray-500">Aktiv (Foydali)</p>
                    <p className="font-bold text-emerald-600">{activeValue.toLocaleString()} so'm</p>
                </div>
            </div>
            <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <div>
                    <p className="text-xs text-gray-500">Zarar (Muddati o'tgan)</p>
                    <p className="font-bold text-red-600">{wastedValue.toLocaleString()} so'm</p>
                </div>
            </div>
        </div>
      </div>

      <div className="relative w-40 h-40 flex items-center justify-center">
        <svg className="w-full h-full transform -rotate-90" viewBox="0 0 200 200">
            {/* Background Circle */}
            <circle
                cx="100"
                cy="100"
                r={radius}
                className="stroke-gray-100"
                strokeWidth="20"
                fill="transparent"
            />
            {/* Wasted Circle (Base Red) */}
            <circle
                cx="100"
                cy="100"
                r={radius}
                className="stroke-red-500 transition-all duration-1000 ease-out"
                strokeWidth="20"
                fill="transparent"
                strokeDasharray={circumference}
                strokeDashoffset="0"
            />
            {/* Active Circle (Overlay Green) */}
            <circle
                cx="100"
                cy="100"
                r={radius}
                className="stroke-emerald-500 transition-all duration-1000 ease-out"
                strokeWidth="20"
                fill="transparent"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={activeOffset}
            />
        </svg>
        <div className="absolute flex flex-col items-center">
            <span className="text-sm text-gray-400">Jami</span>
            <span className="font-bold text-gray-800">{totalValue > 0 ? (totalValue / 1000).toFixed(0) + 'k' : '0'}</span>
        </div>
      </div>
    </div>
  );
};
