import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatsCardProps {
  title: string;
  value: number;
  icon: LucideIcon;
  colorClass: string;
  bgClass: string;
}

export const StatsCard: React.FC<StatsCardProps> = ({ title, value, icon: Icon, colorClass, bgClass }) => {
  return (
    <div className={`${bgClass} p-4 rounded-xl shadow-sm border border-opacity-10 flex items-center justify-between`}>
      <div>
        <p className="text-sm text-gray-600 font-medium mb-1">{title}</p>
        <h3 className={`text-2xl font-bold ${colorClass}`}>{value}</h3>
      </div>
      <div className={`p-3 rounded-full ${colorClass} bg-opacity-10`}>
        <Icon size={24} className={colorClass} />
      </div>
    </div>
  );
};