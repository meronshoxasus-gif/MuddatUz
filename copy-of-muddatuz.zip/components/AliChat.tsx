
import React, { useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import { Send, Bot, User as UserIcon, Loader2 } from 'lucide-react';

interface AliChatProps {
  messages: ChatMessage[];
  input: string;
  setInput: (val: string) => void;
  onSend: () => void;
  isLoading: boolean;
}

export const AliChat: React.FC<AliChatProps> = ({ messages, input, setInput, onSend, isLoading }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  return (
    <div className="flex flex-col h-full bg-gray-50 relative">
      <div className="absolute top-0 w-full h-4 bg-gradient-to-b from-gray-50 to-transparent z-10" />
      
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 pb-24">
        {messages.length === 0 && (
          <div className="text-center py-10 opacity-60 mt-10">
            <div className="w-20 h-20 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Bot className="text-indigo-600" size={40} />
            </div>
            <h3 className="font-bold text-gray-800 text-lg">Men Ali, yordamchingizman!</h3>
            <p className="text-sm text-gray-500 mt-2 px-6">Men mahsulotlaringiz muddatini bilaman va retseptlar bera olaman. Menga yozing!</p>
          </div>
        )}

        {messages.map((msg, idx) => (
          <div key={idx} className={`flex w-full ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`flex max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'} gap-2 items-end`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 shadow-sm ${
                msg.role === 'user' ? 'bg-indigo-600' : 'bg-white border border-gray-200'
              }`}>
                {msg.role === 'user' ? <UserIcon size={14} className="text-white" /> : <Bot size={16} className="text-indigo-600" />}
              </div>
              <div className={`px-4 py-3 rounded-2xl text-sm leading-relaxed shadow-sm ${
                msg.role === 'user' 
                  ? 'bg-indigo-600 text-white rounded-br-none' 
                  : 'bg-white text-gray-800 border border-gray-100 rounded-bl-none'
              }`}>
                {msg.content}
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
             <div className="bg-white px-4 py-3 rounded-2xl rounded-bl-none border border-gray-100 flex items-center gap-2 ml-10 shadow-sm">
                <Loader2 size={16} className="animate-spin text-indigo-500" />
                <span className="text-xs text-gray-400">Ali o'ylamoqda...</span>
             </div>
          </div>
        )}
      </div>

      <div className="absolute bottom-0 w-full p-4 bg-white border-t border-gray-100">
        <form 
          onSubmit={(e) => { e.preventDefault(); onSend(); }}
          className="flex items-center gap-2 bg-gray-100 rounded-full px-4 py-2 border border-gray-200 focus-within:border-indigo-500 focus-within:ring-2 focus-within:ring-indigo-100 transition"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Xabar yozing..."
            className="flex-1 bg-transparent border-none focus:ring-0 text-sm py-2 outline-none text-gray-800"
          />
          <button 
            type="submit" 
            disabled={!input.trim() || isLoading}
            className="p-2 bg-indigo-600 rounded-full text-white hover:bg-indigo-700 disabled:opacity-50 transition shadow-md"
          >
            <Send size={18} />
          </button>
        </form>
      </div>
    </div>
  );
};
