
import React, { useState } from 'react';
import { User } from '../types';
import { ShieldCheck, UserPlus, LogIn } from 'lucide-react';

interface AuthProps {
  onLogin: (user: User) => void;
}

export const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    surname: '',
    age: '',
    email: '',
    password: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (isLogin) {
      const storedUsers = localStorage.getItem('muddatuz_users');
      if (storedUsers) {
        const users: User[] = JSON.parse(storedUsers);
        const user = users.find(u => u.email === formData.email && u.password === formData.password);
        if (user) {
          onLogin(user);
        } else {
          setError("Email yoki parol noto'g'ri!");
        }
      } else {
        setError("Foydalanuvchi topilmadi.");
      }
    } else {
      if (!formData.name || !formData.surname || !formData.email || !formData.password) {
        setError("Barcha maydonlarni to'ldiring!");
        return;
      }
      
      const newUser: User = { ...formData };
      const storedUsers = localStorage.getItem('muddatuz_users');
      const users: User[] = storedUsers ? JSON.parse(storedUsers) : [];
      
      // Check duplicate
      if (users.find(u => u.email === newUser.email)) {
        setError("Bu email allaqachon ro'yxatdan o'tgan.");
        return;
      }

      users.push(newUser);
      localStorage.setItem('muddatuz_users', JSON.stringify(users));
      onLogin(newUser);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-600 to-purple-700 p-4">
      <div className="bg-white/95 backdrop-blur-xl w-full max-w-md p-8 rounded-3xl shadow-2xl">
        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-indigo-100 rounded-2xl flex items-center justify-center mx-auto mb-4 text-indigo-600">
            <ShieldCheck size={32} />
          </div>
          <h1 className="text-3xl font-bold text-gray-800">MuddatUz</h1>
          <p className="text-gray-500 mt-1">Mahsulotlaringiz nazorat ostida</p>
        </div>

        {error && (
          <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm mb-4 text-center border border-red-100">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3">
          {!isLogin && (
            <div className="grid grid-cols-2 gap-3">
              <input
                type="text"
                placeholder="Ism"
                required
                className="w-full bg-gray-50 text-gray-900 px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 outline-none placeholder-gray-400"
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
              />
              <input
                type="text"
                placeholder="Familiya"
                required
                className="w-full bg-gray-50 text-gray-900 px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 outline-none placeholder-gray-400"
                value={formData.surname}
                onChange={e => setFormData({...formData, surname: e.target.value})}
              />
            </div>
          )}

          {!isLogin && (
             <input
               type="number"
               placeholder="Yosh"
               required
               className="w-full bg-gray-50 text-gray-900 px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 outline-none placeholder-gray-400"
               value={formData.age}
               onChange={e => setFormData({...formData, age: e.target.value})}
             />
          )}

          <input
            type="email"
            placeholder="Email"
            required
            className="w-full bg-gray-50 text-gray-900 px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 outline-none placeholder-gray-400"
            value={formData.email}
            onChange={e => setFormData({...formData, email: e.target.value})}
          />

          <input
            type="password"
            placeholder="Parol"
            required
            className="w-full bg-gray-50 text-gray-900 px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 outline-none placeholder-gray-400"
            value={formData.password}
            onChange={e => setFormData({...formData, password: e.target.value})}
          />

          <button
            type="submit"
            className="w-full bg-indigo-600 text-white font-bold py-3.5 rounded-xl hover:bg-indigo-700 active:scale-95 transition flex items-center justify-center gap-2 mt-4"
          >
            {isLogin ? <><LogIn size={20} /> Kirish</> : <><UserPlus size={20} /> Ro'yxatdan o'tish</>}
          </button>
        </form>

        <div className="mt-6 text-center">
          <button
            onClick={() => { setIsLogin(!isLogin); setError(''); }}
            className="text-indigo-600 font-medium hover:underline text-sm"
          >
            {isLogin ? "Akkauntingiz yo'qmi? Ro'yxatdan o'ting" : "Akkauntingiz bormi? Kiring"}
          </button>
        </div>
      </div>
    </div>
  );
};
