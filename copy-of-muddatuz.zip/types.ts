
export enum Category {
  FOOD = 'Oziq-ovqat',
  MEDICINE = 'Dori-darmon',
  COSMETIC = 'Kosmetika',
  SUBSCRIPTION = 'Obuna (Premium)',
  DOCUMENT = 'Hujjat',
  TECH = 'Texnika',
  HOUSEHOLD = 'Ro\'zg\'or',
  OTHER = 'Boshqa'
}

export interface User {
  name: string;
  surname: string;
  age: string;
  email: string;
  password?: string;
}

export interface Product {
  id: string;
  name: string;
  expiryDate: string; // ISO Date string YYYY-MM-DD
  category: Category;
  addedDate: string;
  image?: string; 
  note?: string;
  price?: number; // Added price field
}

export type ViewState = 'dashboard' | 'add' | 'list' | 'chat' | 'profile';

export interface ScanResult {
  name: string;
  expiryDate: string | null;
  category: Category;
  price?: number;
}

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}
